-- Adding script to the Item 6948 ( Hearthstone )
UPDATE `item_template` SET `ScriptName`='character_tools' WHERE `entry`=6948;
