# Learn Highest Talent Rank mod-azerothcore
Learn Highest Talent Rank for AzerothCore 3.3.5

Players will automatically learn the highest talent rank when they click on a talent spell.  
Intended for "instant level 80" private servers.

# Screenshot
![](https://i.ibb.co/gM45ymf/Wo-WScrn-Shot-032019-003120-1.jpg)

# Video Showcase:
https://streamable.com/m3cmz
