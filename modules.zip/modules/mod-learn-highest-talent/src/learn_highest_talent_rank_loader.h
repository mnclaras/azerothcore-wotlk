#ifndef LEARN_HIGHEST_TALENT_RANK_LOADER_H
#define LEARN_HIGHEST_TALENT_RANK_LOADER_H

void AddSC_learn_highest_talent_rank();

void Addlearn_highest_talent_rankScripts()
{
    AddSC_learn_highest_talent_rank();
}

#endif /* LEARN_HIGHEST_TALENT_RANK_LOADER_H */
