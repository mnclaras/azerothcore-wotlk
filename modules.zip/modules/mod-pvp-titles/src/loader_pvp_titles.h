void AddPvpTitlesScripts();
