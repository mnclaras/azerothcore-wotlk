void AddSC_DuelReset();

void AddDuelResetScripts() {
    AddSC_DuelReset();
}