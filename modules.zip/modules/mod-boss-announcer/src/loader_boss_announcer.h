void AddBoss_AnnouncerScripts();
