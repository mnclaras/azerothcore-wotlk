## mod-boss-announcer

# Boss Announcer module for AzerothCore.

Announce if a world boss killed by someone

# Original script:
Reworked by talamortis Still WIP


# Show your appreciation
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=SBJFTAJKUNEXC)
