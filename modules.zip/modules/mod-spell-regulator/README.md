# ViperDev Modules

### This is a module for [AzerothCore](http://www.azerothcore.org)

#### Features:
- Modify the percentage of the spells by regulating in the best way.

### Spell Regulator Module currently requires:
- Warning! for the module to work make the changes of the link below
- For work need new hooks https://gist.github.com/vhiperdev/c3debb0dae1fa6f2591fddacbe311747

### How to install
1. git clone https://github.com/vhipercode/mod-spellregulator.git
2. You can download the module, unzip a folder and update it in the azerothcore / modules directory.
3. Simply place the module under the `modules` folder of your AzerothCore source folder.
4. Re-run cmake and launch a clean build of AzerothCore
5. Done :)
6. Sql - world - spellregulator.sql -> DB world

AzerothCore: [repository](https://github.com/azerothcore) - [website](http://azerothcore.org/) - [discord chat community](https://discord.gg/PaqQRkd)
