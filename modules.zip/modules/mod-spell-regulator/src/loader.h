void AddSC_SpellRegulator();

void AddSpellRegulatorScripts() {
    AddSC_SpellRegulator();
}