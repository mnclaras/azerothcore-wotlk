void AddSC_npc_1v1arena();

void Add1v1ArenaScripts() 
{
    AddSC_npc_1v1arena();
}