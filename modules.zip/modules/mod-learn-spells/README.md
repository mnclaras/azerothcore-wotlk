## mod-learnspells

# LearnAllSpells module for AzerothCore.

LearnAllSpells teach new spells on level-up, like in Cataclysm and up.

# Original script:
http://www.ac-web.org/forums/showthread.php?172918-C-Automatically-Learn-New-Spells