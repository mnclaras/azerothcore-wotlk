void AddLearnAllSpellsScripts();
