void AddSC_AntiAD();

void AddAntiADScripts() {
    AddSC_AntiAD();
}