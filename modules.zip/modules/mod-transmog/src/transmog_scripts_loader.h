#ifndef TRANSMOGR_SCRIPTS_LOADER_H
#define TRANSMOGR_SCRIPTS_LOADER_H

void AddSC_transmog();

void AddTransmogScripts()
{
    AddSC_transmog();
}

#endif /* TRANSMOG_SCRIPTS_LOADER_H */

