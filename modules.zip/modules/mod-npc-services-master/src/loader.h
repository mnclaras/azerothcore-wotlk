void AddSC_Npc_Services();

void AddNpc_ServicesScripts()
{
    AddSC_Npc_Services();
}
