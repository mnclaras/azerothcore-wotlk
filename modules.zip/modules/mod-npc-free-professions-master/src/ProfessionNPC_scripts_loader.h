#ifndef ProfessionNPC_SCRIPTS_LOADER_H
#define ProfessionNPC_SCRIPTS_LOADER_H

void AddSC_Professions();

void AddProfessionNPCScripts()
{
    AddSC_Professions();
}

#endif /* ProfessionNPC_SCRIPTS_LOADER_H */
