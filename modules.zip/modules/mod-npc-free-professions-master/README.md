# ![logo](https://raw.githubusercontent.com/azerothcore/azerothcore.github.io/master/images/logo-github.png) AzerothCore
# Professions NPC
### This is a module for [AzerothCore](http://www.azerothcore.org)
- Latest build status with azerothcore: [![Build Status](https://travis-ci.org/azerothcore/mod-npc-free-professions.svg?branch=master)](https://travis-ci.org/azerothcore/mod-npc-free-professions)

This is a module for [AzerothCore](http://www.azerothcore.org)

Current features:

-** This Module Makes a ProfessionsNPC who give 2 free professions (FULL WITH RECIPES) to player.

Upcoming features:
###1) Worldserver config with number of professions can learn.


## Requirements

ProfessionsNPC currently requires:

AzerothCore v1.0.1+

## How to install

###1) Simply place the module under the `modules` folder of your AzerothCore source folder.

###2) Input the SQL file to the world database.

###3) Re-run cmake and launch a clean build of AzerothCore

**END**





