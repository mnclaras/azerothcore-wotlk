# TemplateNPC-azerothcore
Template NPC for AzerothCore 3.3.5

![](https://i.ibb.co/27WPR5j/Wo-WScrn-Shot-021219-000220.jpg)

Video Showcase:
https://streamable.com/yxv1m
