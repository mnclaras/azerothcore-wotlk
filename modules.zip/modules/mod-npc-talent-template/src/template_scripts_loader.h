#ifndef TEMPLATE_SCRIPTS_LOADER_H
#define TEMPLATE_SCRIPTS_LOADER_H

void AddSC_TemplateNPC();

void AddTemplateNPCScripts()
{
    AddSC_TemplateNPC();
}

#endif /* TEMPLATE_SCRIPTS_LOADER_H */
