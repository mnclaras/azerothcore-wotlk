/*
 * Copyright (С) since 2019 Andrei Guluaev (Winfidonarleyan/Kargatum) https://github.com/Winfidonarleyan 
 * Licence MIT https://opensource.org/MIT
 */

#ifndef _CFBG_LOADER_H_
#define _CFBG_LOADER_H_

// From SC
void AddSC_CFBG();

// Add all
void AddCFBGScripts()
{
    AddSC_CFBG();
}

#endif /* _CFBG_LOADER_H_ */


