void AddSC_FactionIconsChannels();

void AddFactionIconsChannelsScripts() {
    AddSC_FactionIconsChannels();
}