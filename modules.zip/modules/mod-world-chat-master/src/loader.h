void AddSC_WorldChatScripts();

void AddWorldChatScripts() {
	AddSC_WorldChatScripts();
}