## mod-phased-duels

# Phased Duels module for AzerothCore.

Phased Duels module create a separated phase for dueling players.

![Phased Duels](https://github.com/conan513/mod-phased-duels/blob/master/phasedduels.gif)