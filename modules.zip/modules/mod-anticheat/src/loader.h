void AddPassiveAnticheatScripts();
